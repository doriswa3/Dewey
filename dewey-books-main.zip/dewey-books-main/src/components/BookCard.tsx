
import { useState } from "react";
import { Star, Heart } from "lucide-react";

interface BookCardProps {
  cover: string;
  title: string;
  author: string;
  rating?: number;
  liked?: boolean;
}

const BookCard = ({ cover, title, author, rating = 0, liked = false }: BookCardProps) => {
  const [isLiked, setIsLiked] = useState(liked);
  
  return (
    <div className="card group h-full flex flex-col hover:shadow-xl transition-shadow duration-300">
      <div className="relative overflow-hidden rounded-lg mb-4">
        <img 
          src={cover} 
          alt={`${title} by ${author}`} 
          className="w-full h-56 object-cover object-center rounded-lg group-hover:scale-105 transition-transform duration-300"
        />
        <button 
          className="absolute top-2 right-2 bg-white/80 hover:bg-white p-1.5 rounded-full"
          onClick={() => setIsLiked(!isLiked)}
        >
          <Heart 
            size={18} 
            fill={isLiked ? "#7d9b76" : "none"} 
            stroke={isLiked ? "#7d9b76" : "currentColor"} 
            className="text-dewey-green"
          />
        </button>
      </div>
      
      <div className="flex-1">
        <h3 className="font-serif font-medium text-lg mb-1 line-clamp-2">{title}</h3>
        <p className="text-gray-600 text-sm mb-2">{author}</p>
        
        {rating > 0 && (
          <div className="flex items-center">
            {[1, 2, 3, 4, 5].map((star) => (
              <Star
                key={star}
                size={16}
                className={`${
                  star <= rating ? "text-dewey-green fill-dewey-green" : "text-gray-300"
                }`}
              />
            ))}
          </div>
        )}
      </div>
      
      <button className="mt-4 text-sm font-medium text-dewey-green hover:text-dewey-light-green transition-colors">
        Add to Shelf
      </button>
    </div>
  );
};

export default BookCard;
